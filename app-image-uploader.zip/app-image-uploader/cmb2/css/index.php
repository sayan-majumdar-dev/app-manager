<?php
// Silence is golden
