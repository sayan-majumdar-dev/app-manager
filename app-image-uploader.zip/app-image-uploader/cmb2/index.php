<?php // Silence is golden.
